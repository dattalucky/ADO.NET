﻿using Assessment.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class Search : Form
    {
        EmployeeLogic ob;
        public Search()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string i;
            i = Empnametxt.Text.ToString();
            Employee c = ob.Searching(i);
            dataGridView1.Visible = false;
            if (c == null)
            {
                MessageBox.Show("Search Key Not Found");
            }
            else
            {
                MessageBox.Show("Found");
                dataGridView1.Visible = true;
                List<Employee> li = new List<Employee>();
                li.Add(c);
                dataGridView1.DataSource = li;


            }
        }

        private void Search_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float sal;
            sal = float.Parse(Empsalarytxt.Text.ToString());
            Employee es1 = ob.Searchingusngsal(sal);
            if (es1 == null)
            {
                MessageBox.Show("Search name not found");
            }
            else
            {
                dataGridView1.Visible = true;
                List<Employee> li = new List<Employee>();
                li.Add(es1);
                dataGridView1.DataSource = li;
                MessageBox.Show("data found");
            }
        }
    }
}
