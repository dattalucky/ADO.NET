﻿namespace Assessment
{
    partial class Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Phonenumlbl = new System.Windows.Forms.Label();
            this.Emaillbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Empidtxt = new System.Windows.Forms.TextBox();
            this.Phonenumtxt = new System.Windows.Forms.TextBox();
            this.Emailtxt = new System.Windows.Forms.TextBox();
            this.chkbtn = new System.Windows.Forms.Button();
            this.updatebtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(236, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "EMP ID";
            // 
            // Phonenumlbl
            // 
            this.Phonenumlbl.AutoSize = true;
            this.Phonenumlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phonenumlbl.Location = new System.Drawing.Point(236, 130);
            this.Phonenumlbl.Name = "Phonenumlbl";
            this.Phonenumlbl.Size = new System.Drawing.Size(90, 16);
            this.Phonenumlbl.TabIndex = 1;
            this.Phonenumlbl.Text = "PHONE NUM";
            // 
            // Emaillbl
            // 
            this.Emaillbl.AutoSize = true;
            this.Emaillbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillbl.Location = new System.Drawing.Point(236, 167);
            this.Emaillbl.Name = "Emaillbl";
            this.Emaillbl.Size = new System.Drawing.Size(47, 16);
            this.Emaillbl.TabIndex = 2;
            this.Emaillbl.Text = "EMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(235, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(300, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "UPDATE EMPLOYEE DETAILS";
            // 
            // Empidtxt
            // 
            this.Empidtxt.Location = new System.Drawing.Point(425, 87);
            this.Empidtxt.Name = "Empidtxt";
            this.Empidtxt.Size = new System.Drawing.Size(100, 20);
            this.Empidtxt.TabIndex = 4;
            // 
            // Phonenumtxt
            // 
            this.Phonenumtxt.Location = new System.Drawing.Point(425, 130);
            this.Phonenumtxt.Name = "Phonenumtxt";
            this.Phonenumtxt.Size = new System.Drawing.Size(100, 20);
            this.Phonenumtxt.TabIndex = 5;
            // 
            // Emailtxt
            // 
            this.Emailtxt.Location = new System.Drawing.Point(425, 167);
            this.Emailtxt.Name = "Emailtxt";
            this.Emailtxt.Size = new System.Drawing.Size(100, 20);
            this.Emailtxt.TabIndex = 6;
            // 
            // chkbtn
            // 
            this.chkbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbtn.Location = new System.Drawing.Point(437, 205);
            this.chkbtn.Name = "chkbtn";
            this.chkbtn.Size = new System.Drawing.Size(75, 23);
            this.chkbtn.TabIndex = 7;
            this.chkbtn.Text = "CHECK";
            this.chkbtn.UseVisualStyleBackColor = true;
            this.chkbtn.Click += new System.EventHandler(this.chkbtn_Click);
            // 
            // updatebtn
            // 
            this.updatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebtn.Location = new System.Drawing.Point(437, 243);
            this.updatebtn.Name = "updatebtn";
            this.updatebtn.Size = new System.Drawing.Size(88, 23);
            this.updatebtn.TabIndex = 8;
            this.updatebtn.Text = "UPDATE";
            this.updatebtn.UseVisualStyleBackColor = true;
            this.updatebtn.Click += new System.EventHandler(this.updatebtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(23, 282);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(756, 156);
            this.dataGridView1.TabIndex = 9;
            // 
            // Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.updatebtn);
            this.Controls.Add(this.chkbtn);
            this.Controls.Add(this.Emailtxt);
            this.Controls.Add(this.Phonenumtxt);
            this.Controls.Add(this.Empidtxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Emaillbl);
            this.Controls.Add(this.Phonenumlbl);
            this.Controls.Add(this.label1);
            this.Name = "Update";
            this.Text = "Update";
            this.Load += new System.EventHandler(this.Update_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Phonenumlbl;
        private System.Windows.Forms.Label Emaillbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Empidtxt;
        private System.Windows.Forms.TextBox Phonenumtxt;
        private System.Windows.Forms.TextBox Emailtxt;
        private System.Windows.Forms.Button chkbtn;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}